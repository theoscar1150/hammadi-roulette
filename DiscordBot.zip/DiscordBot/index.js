const Discord = require("discord.js");
const bot = new Discord.Client();
const token = 'NzM5OTk1NjUxMjA2NTQ1NDc5.Xyikpw.fCnuFfUMiIdeE22YG0hFDcYoT7A';

let gameOn = false; //determines if the game is on or not
let players = []; // stores the users' ID
let ammo = [0,0,0,0,0,1]; //the bullets in the gun
let bulletPos = 0; //bullet position in gun
let circle = 0; // displays current position of the gun
function addUser(player, msg){ //adds the ID of a player to the array
    if (gameOn == true) {
      msg.channel.send("Game is Full");
    }
    else{
      players.push(player);
      msg.reply("You're Added!");
    }
  }



function beginGame(msg)
{

  //Shuffle Players Array
  players.sort(() => Math.random() - 0.5);

  //Actual Game
  msg.channel.send("Shuffling The Bullets");
  ammo.sort(() => Math.random() - 0.5); //shuffling bullets
  msg.channel.send("In Order to Play The Game, Type !shoot when it is your turn");
  CallPlayer(players,msg);



}

function CallPlayer(players,msg){
  if(circle < players.length - 1){
    circle += 1;
  } else {
    circle = 0;
  }
  bot.users.fetch(players[circle]).then(value => {
    msg.channel.send(value.username + " it is your turn to shoot!");
  });
}

function shootPlayer(msg){
  if(ammo[bulletPos] == 0){
    msg.reply("You Are Alive!");
    bulletPos+=1;
  }
  else {
    temp = []
    msg.reply("You Are Dead!");
    for (var i = 0; i < players.length; i++) {
      if (players[i] == players[circle]) {
        continue;
      }else{
        temp.push(players[i]);
      }
    }
    delete players;
    players = temp;
    delete temp;
    if (players.length != 1) {
      msg.channel.send("Shuffling The Bullets");
      ammo.sort(() => Math.random() - 0.5); //shuffling bullets
      bulletPos = 0;
    }
  }
  if(players.length == 1){
    bot.users.fetch(players[0]).then(value => {
      msg.channel.send(value.username + " is the russian roulette champion");
    });
    stopGame(msg);
  }
  CallPlayer(players,msg);
}

function stopGame(msg) {
  if (gameOn == false) {
    msg.reply("Game is not on");
  } else {
    ammo = [0,0,0,0,0,1];
    circle = 0;
    gameOn = false;
    players = [];
    msg.channel.send("Game is stopped completely!");
  }
}

bot.on('message', msg => {
  if (msg.channel.id === '744595289209307307') {
    if(msg.content === "!add"){ //command for !add
      if (players.includes(msg.author.id)) {
        msg.reply("You already exist in the queue");
      }

    else{
        addUser(msg.author.id, msg)
    }

    }
    else if (msg.content === "!play") { //command for !play
      if (gameOn == true) {
        msg.reply("Game is already On");
      }
      else {
        if (players.length < 2) {
          msg.reply("The Game Needs at least two players");
        }
        else
        {
          msg.channel.send("The Game Shall Begin");
          gameOn = true;
          beginGame(msg);
        }
      }
    }

    else if (msg.content === "!stop") { //stops the game
      stopGame(msg);
    }

    else if(msg.content === "!shoot"){
      if (gameOn == false) {
        msg.reply("game is not active");
      }
      else{
        if (players[circle] == msg.author.id) {
          shootPlayer(msg);
        }
        else {
          msg.reply("It is not your turn yet!");
        }
      }
    }

  }
})

bot.login(token);
